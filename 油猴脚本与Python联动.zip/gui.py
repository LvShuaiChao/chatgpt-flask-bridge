import queue
import time
import tkinter as tk
from tkinter import messagebox, scrolledtext, ttk

import server


class ServerGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("油猴联动服务端")
        self.root.geometry("860x640")
        self.root.minsize(760, 560)

        self.log_queue = queue.Queue()
        server.set_log_callback(self.log_queue.put)
        server.set_status_callback(self._on_bridge_status)

        self._build_ui()
        self._poll_logs()
        self._refresh_status_tick()
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

    def _build_ui(self):
        main = ttk.Frame(self.root, padding=12)
        main.pack(fill=tk.BOTH, expand=True)

        conn = ttk.LabelFrame(main, text="服务连接", padding=10)
        conn.pack(fill=tk.X, pady=(0, 8))

        ttk.Label(conn, text="地址").grid(row=0, column=0, sticky=tk.W, padx=(0, 6))
        self.host_var = tk.StringVar(value="127.0.0.1")
        self.host_entry = ttk.Entry(conn, textvariable=self.host_var, width=16)
        self.host_entry.grid(row=0, column=1, sticky=tk.W)

        ttk.Label(conn, text="端口").grid(row=0, column=2, sticky=tk.W, padx=(16, 6))
        self.port_var = tk.StringVar(value="5000")
        self.port_entry = ttk.Entry(conn, textvariable=self.port_var, width=8)
        self.port_entry.grid(row=0, column=3, sticky=tk.W)

        self.status_var = tk.StringVar(value="服务：未启动")
        ttk.Label(conn, textvariable=self.status_var).grid(row=0, column=4, sticky=tk.W, padx=(20, 0))

        btn_row = ttk.Frame(conn)
        btn_row.grid(row=1, column=0, columnspan=5, sticky=tk.W, pady=(10, 0))
        self.start_btn = ttk.Button(btn_row, text="启动服务", command=self._start_server)
        self.start_btn.pack(side=tk.LEFT, padx=(0, 8))
        self.stop_btn = ttk.Button(btn_row, text="停止服务", command=self._stop_server, state=tk.DISABLED)
        self.stop_btn.pack(side=tk.LEFT)

        tm = ttk.LabelFrame(main, text="油猴连接状态", padding=10)
        tm.pack(fill=tk.X, pady=(0, 8))

        self.tm_online_var = tk.StringVar(value="油猴：未知")
        self.tm_last_seen_var = tk.StringVar(value="最后心跳：-")
        self.tm_page_var = tk.StringVar(value="页面：-")
        self.tm_queue_var = tk.StringVar(value="待发队列：0")

        ttk.Label(tm, textvariable=self.tm_online_var).grid(row=0, column=0, sticky=tk.W)
        ttk.Label(tm, textvariable=self.tm_last_seen_var).grid(row=0, column=1, sticky=tk.W, padx=(24, 0))
        ttk.Label(tm, textvariable=self.tm_queue_var).grid(row=1, column=0, sticky=tk.W, pady=(6, 0))
        ttk.Label(tm, textvariable=self.tm_page_var, wraplength=760).grid(row=2, column=0, columnspan=2, sticky=tk.W, pady=(6, 0))

        paned = ttk.PanedWindow(main, orient=tk.HORIZONTAL)
        paned.pack(fill=tk.BOTH, expand=True, pady=(0, 8))

        send_frame = ttk.LabelFrame(paned, text="发送到油猴 → ChatGPT", padding=10)
        paned.add(send_frame, weight=1)

        self.message_text = scrolledtext.ScrolledText(send_frame, height=10, wrap=tk.WORD, font=("Microsoft YaHei UI", 10))
        self.message_text.pack(fill=tk.BOTH, expand=True)
        self.message_text.insert(tk.END, "你好，这是一条来自服务端的测试消息。")

        send_btns = ttk.Frame(send_frame)
        send_btns.pack(fill=tk.X, pady=(8, 0))
        ttk.Button(send_btns, text="发送消息", command=self._push_message).pack(side=tk.LEFT)
        ttk.Button(send_btns, text="清空输入", command=self._clear_input).pack(side=tk.LEFT, padx=(8, 0))

        recv_frame = ttk.LabelFrame(paned, text="油猴回传（回执 / 事件）", padding=10)
        paned.add(recv_frame, weight=1)

        self.inbound_text = scrolledtext.ScrolledText(recv_frame, height=10, wrap=tk.WORD, state=tk.DISABLED, font=("Consolas", 9))
        self.inbound_text.pack(fill=tk.BOTH, expand=True)

        out_frame = ttk.LabelFrame(main, text="最近发出的消息", padding=10)
        out_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 8))

        cols = ("time", "id", "status", "content")
        self.outbound_tree = ttk.Treeview(out_frame, columns=cols, show="headings", height=5)
        self.outbound_tree.heading("time", text="时间")
        self.outbound_tree.heading("id", text="ID")
        self.outbound_tree.heading("status", text="状态")
        self.outbound_tree.heading("content", text="内容")
        self.outbound_tree.column("time", width=80, anchor=tk.W)
        self.outbound_tree.column("id", width=90, anchor=tk.W)
        self.outbound_tree.column("status", width=80, anchor=tk.W)
        self.outbound_tree.column("content", width=400, anchor=tk.W)
        self.outbound_tree.pack(fill=tk.BOTH, expand=True)

        log_frame = ttk.LabelFrame(main, text="运行日志", padding=10)
        log_frame.pack(fill=tk.BOTH, expand=True)

        self.log_text = scrolledtext.ScrolledText(log_frame, height=6, wrap=tk.WORD, state=tk.DISABLED, font=("Consolas", 9))
        self.log_text.pack(fill=tk.BOTH, expand=True)

        hint = ttk.Label(
            main,
            text="流程：启动服务 → 打开 ChatGPT 并启用 client.user.js → 在此发送消息 → 油猴自动填入并回执。",
            foreground="#555555",
        )
        hint.pack(anchor=tk.W, pady=(6, 0))

    def _format_ts(self, ts):
        if not ts:
            return "-"
        return time.strftime("%H:%M:%S", time.localtime(ts))

    def _on_bridge_status(self, status):
        self.root.after(0, lambda: self._apply_bridge_status(status))

    def _apply_bridge_status(self, status):
        if status["server_running"]:
            self.status_var.set(f"服务：运行中（{self.host_var.get()}:{self.port_var.get()}）")
        else:
            self.status_var.set("服务：未启动")

        if status["tampermonkey_online"]:
            self.tm_online_var.set("油猴：在线")
        elif status["tampermonkey_last_seen"]:
            self.tm_online_var.set("油猴：离线")
        else:
            self.tm_online_var.set("油猴：未连接")

        self.tm_last_seen_var.set(f"最后心跳：{self._format_ts(status['tampermonkey_last_seen'])}")
        self.tm_queue_var.set(f"待发队列：{status['queue_length']}")
        page = status.get("tampermonkey_page_url") or "-"
        if len(page) > 90:
            page = page[:90] + "..."
        self.tm_page_var.set(f"页面：{page}")

        self._render_inbound(status.get("recent_inbound") or [])
        self._render_outbound(status.get("recent_outbound") or [])

    def _render_inbound(self, items):
        self.inbound_text.configure(state=tk.NORMAL)
        self.inbound_text.delete("1.0", tk.END)
        for item in reversed(items):
            ts = self._format_ts(item.get("time"))
            kind = item.get("kind", "?")
            payload = item.get("payload") or {}
            line = f"[{ts}] {kind} {payload}\n"
            self.inbound_text.insert(tk.END, line)
        if not items:
            self.inbound_text.insert(tk.END, "（暂无回传）\n")
        self.inbound_text.configure(state=tk.DISABLED)

    def _render_outbound(self, items):
        for row in self.outbound_tree.get_children():
            self.outbound_tree.delete(row)
        for item in reversed(items):
            content = item.get("content", "")
            if len(content) > 60:
                content = content[:60] + "..."
            self.outbound_tree.insert(
                "",
                tk.END,
                values=(
                    self._format_ts(item.get("acked_at") or item.get("delivered_at") or item.get("created_at")),
                    (item.get("id") or "")[:8] + "…",
                    item.get("status", ""),
                    content,
                ),
            )

    def _refresh_status_tick(self):
        if server.is_server_running():
            self._apply_bridge_status(server.get_bridge_status())
        self.root.after(1000, self._refresh_status_tick)

    def _append_log(self, message):
        self.log_text.configure(state=tk.NORMAL)
        self.log_text.insert(tk.END, message + "\n")
        self.log_text.see(tk.END)
        self.log_text.configure(state=tk.DISABLED)

    def _poll_logs(self):
        while True:
            try:
                message = self.log_queue.get_nowait()
            except queue.Empty:
                break
            self._append_log(message)
        self.root.after(200, self._poll_logs)

    def _update_running_ui(self, running):
        entry_state = tk.DISABLED if running else tk.NORMAL
        self.host_entry.configure(state=entry_state)
        self.port_entry.configure(state=entry_state)

        if running:
            self.start_btn.configure(state=tk.DISABLED)
            self.stop_btn.configure(state=tk.NORMAL)
        else:
            self.start_btn.configure(state=tk.NORMAL)
            self.stop_btn.configure(state=tk.DISABLED)

    def _parse_port(self):
        try:
            port = int(self.port_var.get().strip())
        except ValueError:
            messagebox.showerror("端口错误", "端口必须是数字。")
            return None
        if not (1 <= port <= 65535):
            messagebox.showerror("端口错误", "端口范围应为 1–65535。")
            return None
        return port

    def _start_server(self):
        host = self.host_var.get().strip() or "127.0.0.1"
        port = self._parse_port()
        if port is None:
            return
        if server.start_server(host, port):
            self._update_running_ui(True)
            self._apply_bridge_status(server.get_bridge_status())
        else:
            messagebox.showwarning("提示", "服务已在运行中。")

    def _stop_server(self):
        if server.stop_server():
            self._update_running_ui(False)
            self._apply_bridge_status(server.get_bridge_status())

    def _push_message(self):
        if not server.is_server_running():
            messagebox.showwarning("提示", "请先启动服务。")
            return
        content = self.message_text.get("1.0", tk.END).strip()
        if not content:
            messagebox.showwarning("提示", "请输入要发送的内容。")
            return
        server.push_message(content)

    def _clear_input(self):
        self.message_text.delete("1.0", tk.END)

    def _on_close(self):
        if server.is_server_running():
            server.stop_server()
        self.root.destroy()


def main():
    root = tk.Tk()
    try:
        ttk.Style().theme_use("vista")
    except tk.TclError:
        pass
    ServerGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
