// ==UserScript==
// @name         ChatGPT 客户端 - Flask 轮询联动
// @namespace    http://tampermonkey.net/
// @version      1.1
// @description  与本地 Flask 服务端双向交互：轮询消息、回执确认、上报事件
// @author       You
// @match        https://chatgpt.com/*
// @connect      127.0.0.1
// @connect      localhost
// @grant        GM_xmlhttpRequest
// ==/UserScript==

(function() {
    'use strict';

    const BRIDGE_URL = 'http://127.0.0.1:5000/api/bridge';
    const SOURCE = 'tampermonkey';
    const CLIENT_ID = 'tm-' + Math.random().toString(36).slice(2, 10);
    const POLL_INTERVAL_MS = 1000;

    let handlingMessageId = null;

    function apiRequest(body) {
        return new Promise((resolve, reject) => {
            GM_xmlhttpRequest({
                method: 'POST',
                url: BRIDGE_URL,
                headers: {
                    'Content-Type': 'application/json',
                    'X-Request-Source': SOURCE
                },
                data: JSON.stringify({
                    client_id: CLIENT_ID,
                    page_url: location.href,
                    ...body
                }),
                onload: function(response) {
                    try {
                        resolve(JSON.parse(response.responseText));
                    } catch (e) {
                        reject(new Error('响应解析失败'));
                    }
                },
                onerror: function(error) {
                    reject(error);
                }
            });
        });
    }

    function report(event, payload, messageId) {
        return apiRequest({
            action: 'report',
            event: event,
            payload: payload || {},
            message_id: messageId || null
        }).catch(() => {});
    }

    function ack(messageId, success, detail) {
        return apiRequest({
            action: 'ack',
            message_id: messageId,
            success: success,
            detail: detail || ''
        });
    }

    function sendToChatGPT(text) {
        const input = document.querySelector('#prompt-textarea');
        if (!input) {
            return { ok: false, detail: '未找到输入框 #prompt-textarea' };
        }

        input.innerHTML = text;
        input.dispatchEvent(new InputEvent('input', { bubbles: true, cancelable: true }));

        const sendButton = document.querySelector('[data-testid="send-button"]');
        if (!sendButton) {
            return { ok: false, detail: '未找到发送按钮' };
        }

        sendButton.click();
        return { ok: true, detail: '已填入并点击发送' };
    }

    function clickExtraButton() {
        const xpath = "/html/body/div[1]/div/div[1]/div/main/div/div/div[2]/div[1]/div/div/div[2]/form/div[2]/div/div[3]/div/button";
        const button = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
        if (button) {
            button.click();
            return true;
        }
        return false;
    }

    async function handleOutboundMessage(result) {
        if (!result.has_message || !result.content) {
            return;
        }

        const messageId = result.message_id;
        if (handlingMessageId === messageId) {
            return;
        }
        handlingMessageId = messageId;

        if (result.retry) {
            console.log('[联动] 重试下发消息', messageId);
        } else {
            console.log('[联动] 收到新消息', messageId);
        }

        const sendResult = sendToChatGPT(result.content);

        if (sendResult.ok) {
            setTimeout(() => {
                if (!clickExtraButton()) {
                    report('extra_button_skip', { reason: '未找到附加按钮' }, messageId);
                }
            }, 1000);
        }

        try {
            await ack(messageId, sendResult.ok, sendResult.detail);
        } finally {
            if (handlingMessageId === messageId) {
                handlingMessageId = null;
            }
        }

        if (!sendResult.ok) {
            await report('send_failed', { detail: sendResult.detail }, messageId);
        }
    }

    async function pollBridge() {
        try {
            const result = await apiRequest({ action: 'poll' });
            await handleOutboundMessage(result);
        } catch (error) {
            console.error('[联动] 连接服务端失败', error);
        }
    }

    pollBridge();
    setInterval(pollBridge, POLL_INTERVAL_MS);
})();
